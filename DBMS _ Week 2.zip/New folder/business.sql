-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2022 at 09:44 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `business`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_info`
--

CREATE TABLE `customer_info` (
  `Customer_id` int(11) NOT NULL,
  `Customer_name` varchar(20) NOT NULL,
  `First_sale_date` date NOT NULL,
  `Total_Sales_Number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_info`
--

INSERT INTO `customer_info` (`Customer_id`, `Customer_name`, `First_sale_date`, `Total_Sales_Number`) VALUES
(100, 'Rohan', '2019-10-10', 456),
(101, 'Prithvi', '2021-08-07', 350),
(102, 'Porombrata', '2022-02-12', 51);

-- --------------------------------------------------------

--
-- Table structure for table `product_info`
--

CREATE TABLE `product_info` (
  `Part_Number` varchar(20) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Cost` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_info`
--

INSERT INTO `product_info` (`Part_Number`, `Quantity`, `Cost`) VALUES
('120', 30, 4500),
('220', 45, 6500),
('320', 10, 9000);

-- --------------------------------------------------------

--
-- Table structure for table `sales_info`
--

CREATE TABLE `sales_info` (
  `Item_sold` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Price` int(11) NOT NULL,
  `Profit` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales_info`
--

INSERT INTO `sales_info` (`Item_sold`, `Date`, `Price`, `Profit`) VALUES
(12, '2021-11-23', 1000, 50),
(22, '2021-12-03', 1500, 150),
(40, '2022-02-03', 17800, 4450);

-- --------------------------------------------------------

--
-- Table structure for table `store_info`
--

CREATE TABLE `store_info` (
  `Employee_id` int(11) NOT NULL,
  `Employee_name` varchar(255) NOT NULL,
  `Employee_roles` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store_info`
--

INSERT INTO `store_info` (`Employee_id`, `Employee_name`, `Employee_roles`) VALUES
(1, 'Tatha', 'salesman'),
(2, 'Rakula', 'Ho'),
(3, 'Pamela', 'Analyst');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_info`
--

CREATE TABLE `supplier_info` (
  `Supplier_name` varchar(50) NOT NULL,
  `Delivery_time` date NOT NULL,
  `Next_delivery_date` date NOT NULL,
  `Expected_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier_info`
--

INSERT INTO `supplier_info` (`Supplier_name`, `Delivery_time`, `Next_delivery_date`, `Expected_qty`) VALUES
('ABC solution', '2021-12-29', '2022-01-04', 79),
('Infos tech', '2022-03-16', '2022-03-28', 46),
('RNC Enterprice', '2022-02-28', '2022-03-08', 102);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_info`
--
ALTER TABLE `customer_info`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `store_info`
--
ALTER TABLE `store_info`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `supplier_info`
--
ALTER TABLE `supplier_info`
  ADD PRIMARY KEY (`Supplier_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_info`
--
ALTER TABLE `customer_info`
  MODIFY `Customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `store_info`
--
ALTER TABLE `store_info`
  MODIFY `Employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
